package core;

public class Initialize {
	public static void main(String args[]) {
		new Runner();
	}
}

package core.gfx;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import core.Runner;
import core.actionListeners.KeyStrokes;
import core.entities.tools.Tool;

public class Player {

	public static int[] loc = new int[2];
	private Image costume = passets.dplayer0;
	public static Rectangle playerHB = new Rectangle(48, 60);
	private static Tool inHand = Tool.handTool;
	private boolean moving = false;
	public static int direction = 0;

	public Player() {
		loc[0] = (Runner.WIDTH / 2) - (64 / 2);
		loc[1] = (Runner.HEIGHT / 2) - (64 / 2);
		playerHB.setLocation((Runner.WIDTH / 2) - playerHB.width / 2, (Runner.HEIGHT / 2) - playerHB.height / 2);
	}
	
	public static void spawnAttck() {
		inHand.useTool();
	}
	public final void render(Graphics2D g) {
		g.drawImage(costume, loc[0], loc[1], 64, 64, null);
		// Graphics2D g2 = (Graphics2D) g;
		// g2.draw(playerHB);
	}

	public final void tick() {
		moving = false;
		for (int i = 0; i < KeyStrokes.move.length; i++) {
			if (KeyStrokes.move[i] != 0)
				moving = true;
		}
		changeDirection();
		if (moving)
			if (direction == 0) {
				if (Runner.ticks % 12 == 0.0) {
					if (costume == passets.dplayer0) {
						costume = passets.dplayer1;
					} else
						costume = passets.dplayer0;
				}
			}else if (direction == 1) {
				if (Runner.ticks % 15 == 0.0) {
					if (costume == passets.lplayer0)
						costume = passets.lplayer1;
					else
						costume = passets.lplayer0;
				}
			} else if (direction == 2) {
				if (Runner.ticks % 15 == 0.0) {
					if (costume == passets.uplayer0)
						costume = passets.uplayer1;
					else
						costume = passets.uplayer0;
				}
			} else if (direction == 3) {
				if (Runner.ticks % 15 == 0.0) {
					if (costume == passets.rplayer0) {
						costume = passets.rplayer1;
					} else
						costume = passets.rplayer0;
				}
			} 
	}

	private void changeDirection() {
		if (direction == 1 && KeyStrokes.move[0] != 0) {
			return;
		} else if (direction == 0 && KeyStrokes.move[3] != 0) {
			return;
		} else if (direction == 3 && KeyStrokes.move[2] != 0) {
			return;
		} else if (direction == 2 && KeyStrokes.move[1] != 0) {
			return;
		}
		if(direction != 0 && KeyStrokes.move[3] != 0) {
			direction = 0;
			costume = passets.dplayer0;
		} else if(direction != 1 && KeyStrokes.move[0] != 0) {
			direction = 1;
			costume = passets.lplayer0;
		} else if(direction != 2 && KeyStrokes.move[1] != 0) {
			direction = 2;
			costume = passets.uplayer0;
		} else if(direction != 3 && KeyStrokes.move[2] != 0) {
			direction = 3;
			costume = passets.rplayer0;
		}
		
	}
}

class passets {
	public static Image dplayer0 = Sprites.tile(0, 1, 2, 2);
	public static Image dplayer1 = Sprites.tile(2, 1, 2, 2);
	public static Image uplayer0 = Sprites.tile(0, 3, 2, 2);
	public static Image uplayer1 = Sprites.tile(2, 3, 2, 2);
	public static Image rplayer0 = Sprites.tile(0, 5, 2, 2);
	public static Image rplayer1 = Sprites.tile(2, 5, 2, 2);
	public static Image lplayer0 = Sprites.tile(0, 7, 2, 2);
	public static Image lplayer1 = Sprites.tile(2, 7, 2, 2);
}

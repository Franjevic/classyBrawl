package core.entities;

import java.awt.Graphics;
import java.awt.Image;

import core.entities.resources.Resource;
import core.gfx.Text;

public class InventorySlot {
	
	public boolean full;

	private Resource resource;

	private int amount = 0;

	private int maxCount = 0;

	public boolean filled = false;

	private Image text;

	public void render(Graphics g, int[] loc, int[] dimension) {
		g.fillRect(loc[0], loc[1], dimension[0], dimension[1]);
		if(filled) {
			if(resource != null) {
				g.drawImage(resource.sprite,loc[0],loc[1],dimension[0],dimension[1],null);
				g.drawImage(text, loc[0], loc[1] + 30, null);
			}
		}
		
	}
	
	public String getType() {
		return resource.name;
	}

	public boolean canPut() {
		return amount<maxCount;
	}
	
	private void img() {
		this.text = Text.text(amount + "/" + maxCount, 8, 0);
	}

	public void addConcurrent(Resource res) {
		amount++;
		if(amount == maxCount)
			full = true;
		img();
	}
	
	public void putNew(Resource res) {
		filled = true;
		this.resource = res;
		amount++;
		maxCount = res.maxHold;
		img();
	}

}

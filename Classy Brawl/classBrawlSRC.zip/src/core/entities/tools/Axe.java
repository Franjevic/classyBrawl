package core.entities.tools;

public class Axe extends Tool{
	
	public Axe(int level) {
		super(level);
	}

}

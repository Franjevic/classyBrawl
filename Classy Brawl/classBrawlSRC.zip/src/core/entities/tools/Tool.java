package core.entities.tools;

import java.util.Random;

import core.gfx.Player;

public class Tool {
	protected Random random = new Random();
	protected int level;
	public static Tool handTool = new Tool(1);
	
	public Tool(int level) {
		this.level = level;
	}
	public void tick() {
		
	}

	public void useTool() {
		UseHandler.useHandler.add(new ToolUse(Player.direction, level));
	}

}

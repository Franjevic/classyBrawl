package core.entities.windows;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import core.Runner;
import core.entities.InventorySlot;
import core.entities.resources.Resource;
import core.gfx.Text;

public class Inventory {

	public static boolean display = false;

	static InventorySlot[] slots = new InventorySlot[24];
	Image label;
	Image toUse;

	static int selected = 0;

	public Inventory() {
		for (int i = 0; i < slots.length; i++) {
			slots[i] = new InventorySlot();
		}
		label = Text.text("Inventory", 24, 0);
		toUse = Text.text("press e to use", 16, 8);
	}

	public static void display(boolean a) {
		display = a;
	}

	public static void shift(int direction) {
		if(display) {
			selected = (int) Runner.clamp(selected, selected + direction, 0, slots.length - 1);
		}
	}

	public void render(Graphics g) {

		g.setColor(Color.gray);
		if (display) {
			g.drawImage(label, Runner.WIDTH / 2 - label.getWidth(null) / 2, Runner.HEIGHT / 2 - (label.getHeight(null) + 42), null);
			g.drawImage(toUse, Runner.WIDTH / 2 - toUse.getWidth(null) / 2, Runner.HEIGHT / 2 + 30, null);
			for (int i = 0; i < slots.length; i++) {
				slots[i].render(g, new int[] { (Runner.WIDTH / 2 - 16 + 100 * (i - selected)), Runner.HEIGHT / 2 - 16 },
						new int[] { 32, 32 });
			}
		}
	}

	public static void doPickUp(Resource resource) {
		for(int i = 0; i < slots.length; i++) {
			if(slots[i].filled && slots[i].getType().equals(resource.name) && !slots[i].full) {
				slots[i].addConcurrent(resource);
				break;
			}
			else if(!slots[i].filled) {
				slots[i].putNew(resource);
				break;
			}
		}
	}

}
